using System.Windows;
using System.Windows.Controls;
using PS3SaveManager.Services;

namespace PS3SaveManager.Windows;

public partial class CryptoLabWindow : Window
{
    private readonly string[] _files;
    private readonly CryptoLabService _lab = new();

    public CryptoLabWindow(IEnumerable<string> files)
    {
        InitializeComponent();
        _files = files.Where(File.Exists).ToArray();
        FilesList.ItemsSource = _files.Select(Path.GetFileName);
        if (_files.Length > 0) FilesList.SelectedIndex = 0;
    }

    private void FilesList_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (FilesList.SelectedIndex < 0 || FilesList.SelectedIndex >= _files.Length) return;
        try
        {
            var analysis = _lab.Analyze(_files[FilesList.SelectedIndex]);
            ResultBox.Text =
                $"File: {analysis.FileName}\n" +
                $"Size: {analysis.Size:N0} bytes\n" +
                $"Entropy: {analysis.Entropy:F4} / 8.0000\n" +
                $"Printable: {analysis.PrintablePercent}%\n" +
                $"Magic: {analysis.Magic}\n" +
                $"Classification: {analysis.Classification}\n\n" +
                string.Join("\n", analysis.Notes.Select(x => "• " + x));
        }
        catch (Exception ex)
        {
            ResultBox.Text = "Analysis failed:\n\n" + ex.Message;
        }
    }

    private void Decode_OnClick(object sender, RoutedEventArgs e)
    {
        if (FilesList.SelectedIndex < 0 || FilesList.SelectedIndex >= _files.Length) return;
        var source = _files[FilesList.SelectedIndex];
        if (!File.Exists(source))
        {
            MessageBox.Show(this, "The selected payload file no longer exists.", "Save Crypto Lab", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var sourceDirectory = Path.GetDirectoryName(source) ?? ".";
        var saveName = Path.GetFileName(sourceDirectory);
        var parent = Directory.GetParent(sourceDirectory)?.FullName ?? sourceDirectory;
        var decodedDirectory = Path.Combine(parent, "PS3_Save_Manager_Decoded", saveName);
        Directory.CreateDirectory(decodedDirectory);
        var output = GetUniqueOutputPath(Path.Combine(decodedDirectory, Path.GetFileName(source) + ".decoded"));
        var result = _lab.DecodeKnownLayer(source, output);
        MessageBox.Show(
            this,
            result is null ? "No exact reversible wrapper was recognized." : $"{result}.\n\nOutput: {output}",
            "Save Crypto Lab",
            MessageBoxButton.OK,
            result is null ? MessageBoxImage.Information : MessageBoxImage.None);
    }

    private static string GetUniqueOutputPath(string requested)
    {
        if (!File.Exists(requested)) return requested;
        var directory = Path.GetDirectoryName(requested) ?? ".";
        var name = Path.GetFileNameWithoutExtension(requested);
        var extension = Path.GetExtension(requested);
        for (var i = 1; i < 10000; i++)
        {
            var candidate = Path.Combine(directory, $"{name}.{i}{extension}");
            if (!File.Exists(candidate)) return candidate;
        }
        throw new IOException("Could not allocate a unique decoded output filename.");
    }

    private void Close_OnClick(object sender, RoutedEventArgs e) => Close();
}
