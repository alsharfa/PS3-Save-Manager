using System.Diagnostics;

namespace PS3SaveManager.Services;

public sealed record PfdResult(int ExitCode, string Output, bool Success);

public sealed class PfdToolService
{
    private readonly string _sourceExe;
    private readonly string _configDir;
    private readonly string _runtimeDir;

    public PfdToolService(string appDir)
    {
        _sourceExe = Path.Combine(appDir, "pfdtool.exe");
        _configDir = Path.Combine(appDir, "Config");

        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(local))
            local = Path.GetTempPath();
        _runtimeDir = Path.Combine(local, "PS3 Save Manager", "Runtime", "pfdtool");
    }

    private string PrepareRuntime()
    {
        if (!File.Exists(_sourceExe))
            throw new FileNotFoundException("Bundled pfdtool.exe is missing.", _sourceExe);

        var required = new[] { "games.conf", "global.conf" };
        foreach (var name in required)
        {
            var source = Path.Combine(_configDir, name);
            if (!File.Exists(source))
                throw new FileNotFoundException($"Required pfdtool configuration is missing: {source}", source);
        }

        Directory.CreateDirectory(_runtimeDir);
        var runtimeExe = Path.Combine(_runtimeDir, "pfdtool.exe");
        File.Copy(_sourceExe, runtimeExe, true);
        foreach (var name in required)
            File.Copy(Path.Combine(_configDir, name), Path.Combine(_runtimeDir, name), true);

        return runtimeExe;
    }

    public async Task<PfdResult> RunAsync(
        string titleId,
        string action,
        string saveFolder,
        IEnumerable<string>? files = null,
        TimeSpan? timeout = null)
    {
        if (string.IsNullOrWhiteSpace(titleId))
            return new(-1, "The save Title ID could not be determined.", false);
        if (!Directory.Exists(saveFolder))
            return new(-1, "The selected save folder no longer exists.", false);

        string runtimeExe;
        try
        {
            runtimeExe = PrepareRuntime();
        }
        catch (Exception ex)
        {
            return new(-1, ex.Message, false);
        }

        var args = new List<string> { "-g", titleId, action, saveFolder };
        if (files != null)
            args.AddRange(files.Where(x => !string.IsNullOrWhiteSpace(x)));

        var psi = new ProcessStartInfo(runtimeExe)
        {
            WorkingDirectory = _runtimeDir,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        foreach (var arg in args)
            psi.ArgumentList.Add(arg);

        try
        {
            using var process = new Process { StartInfo = psi };
            if (!process.Start())
                return new(-1, "pfdtool.exe could not be started.", false);

            var stdoutTask = process.StandardOutput.ReadToEndAsync();
            var stderrTask = process.StandardError.ReadToEndAsync();
            using var cts = new CancellationTokenSource(timeout ?? TimeSpan.FromMinutes(10));

            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                try { process.Kill(entireProcessTree: true); } catch { }
                var timedOutOutput = ((await stdoutTask) + Environment.NewLine + (await stderrTask)).Trim();
                return new(-1, "pfdtool timed out after 10 minutes.\n\n" + timedOutOutput, false);
            }

            var text = ((await stdoutTask) + Environment.NewLine + (await stderrTask)).Trim();
            var verifyAction = action.Equals("-c", StringComparison.OrdinalIgnoreCase);
            var badText = text.Contains("error:", StringComparison.OrdinalIgnoreCase)
                || text.Contains("[error]", StringComparison.OrdinalIgnoreCase)
                || text.Contains("fatal:", StringComparison.OrdinalIgnoreCase)
                || (verifyAction && (
                    text.Contains("failed", StringComparison.OrdinalIgnoreCase)
                    || text.Contains("invalid", StringComparison.OrdinalIgnoreCase)
                    || text.Contains("mismatch", StringComparison.OrdinalIgnoreCase)));
            var ok = process.ExitCode == 0 && !badText;
            return new(process.ExitCode, text, ok);
        }
        catch (Exception ex)
        {
            return new(-1, ex.ToString(), false);
        }
    }

    public static void CleanupMarkers(string folder)
    {
        foreach (var name in new[]
        {
            "~files_decrypted_by_pfdtool.txt",
            "~files_encrypted_by_pfdtool.txt",
            "~FILES_DECRYPTED_BY_PFDTOOL.TXT",
            "~FILES_ENCRYPTED_BY_PFDTOOL.TXT"
        })
        {
            var path = Path.Combine(folder, name);
            try { if (File.Exists(path)) File.Delete(path); } catch { }
        }
    }
}
