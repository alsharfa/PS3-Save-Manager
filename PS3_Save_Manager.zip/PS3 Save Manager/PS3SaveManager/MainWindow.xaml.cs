using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using PS3SaveManager.Models;
using PS3SaveManager.Services;
using PS3SaveManager.Windows;

namespace PS3SaveManager;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<SaveEntry> _saves = new();
    private readonly string _appDir = AppContext.BaseDirectory;
    private readonly SfoService _sfo = new();
    private readonly SettingsService _settings = new();
    private readonly BackupService _backups = new();
    private GameConfigService _games = null!;
    private SaveScannerService _scanner = null!;
    private PfdToolService _pfd = null!;

    private string? _profilePath;
    private string? _lastBackup;
    private string? _lastBackupTarget;
    private string? _copiedSave;
    private string? _currentRoot;
    private string? _deletedBackup;
    private string? _deletedParent;
    private string? _deletedFolderName;
    private bool _operationInProgress;

    private SaveEntry? Selected => SavesList.SelectedItem as SaveEntry;

    public MainWindow()
    {
        InitializeComponent();
        _games = new GameConfigService(Path.Combine(_appDir, "Config", "games.conf"));
        _scanner = new SaveScannerService(_sfo, _games);
        _pfd = new PfdToolService(_appDir);
        SavesList.ItemsSource = _saves;
    }

    private async void Window_OnLoaded(object sender, RoutedEventArgs e)
    {
        LoadRememberedProfile();
        await ScanUsbAsync();
    }

    private void LoadRememberedProfile()
    {
        var path = _settings.LoadProfilePath();
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            ProfileIdText.Text = "No profile selected";
            ProfilePathText.Text = "Choose once — used automatically every time";
            RememberedText.Text = "Not set";
            return;
        }

        try
        {
            _sfo.Parse(path);
            _profilePath = path;
            ApplyProfileDisplay(path);
            Status("Remembered user profile loaded automatically.");
        }
        catch
        {
            _profilePath = null;
            ProfileIdText.Text = "No profile selected";
            ProfilePathText.Text = "Remembered PARAM.SFO is unavailable or invalid";
            RememberedText.Text = "Not set";
        }
    }

    private void ApplyProfileDisplay(string path)
    {
        var meta = _sfo.Parse(path);
        ProfileIdText.Text = meta.TryGetValue("ACCOUNT_ID", out var id) && !string.IsNullOrWhiteSpace(id)
            ? id
            : "Remembered profile";
        ProfilePathText.Text = $"{Path.GetFileName(path)} · used automatically every time";
        RememberedText.Text = "Remembered";
    }

    private async Task ScanUsbAsync()
    {
        if (!TryBeginOperation("Scanning for PS3 saves…")) return;
        try
        {
            _currentRoot = null;
            _saves.Clear();
            foreach (var root in _scanner.CandidateUsbRoots())
            {
                foreach (var folder in _scanner.FindSaveFolders(root))
                    TryAdd(folder);
            }

            if (_saves.Count > 0)
            {
                SavesList.SelectedIndex = 0;
                Status($"Found {_saves.Count} PS3 save(s).");
            }
            else
            {
                ResetDetails();
                Status("No PS3 USB saves found. Use Browse Saves…");
            }
            await Task.CompletedTask;
        }
        finally
        {
            EndOperation();
        }
    }

    private void TryAdd(string folder)
    {
        try
        {
            var full = Path.GetFullPath(folder);
            if (_saves.Any(x => Path.GetFullPath(x.FolderPath).Equals(full, StringComparison.OrdinalIgnoreCase)))
                return;
            _saves.Add(_scanner.Load(folder));
        }
        catch (Exception ex)
        {
            AppendLog($"Could not load {folder}: {ex.Message}");
        }
    }

    private void UpsertEntry(string folder)
    {
        var full = Path.GetFullPath(folder);
        var fresh = _scanner.Load(folder);
        var index = _saves.Select((entry, i) => new { entry, i })
            .FirstOrDefault(x => Path.GetFullPath(x.entry.FolderPath).Equals(full, StringComparison.OrdinalIgnoreCase))?.i ?? -1;

        if (index >= 0)
        {
            _saves[index] = fresh;
            SavesList.SelectedIndex = index;
        }
        else
        {
            _saves.Add(fresh);
            SavesList.SelectedItem = fresh;
        }
    }

    private void LoadRoot(string root)
    {
        _currentRoot = root;
        _saves.Clear();
        foreach (var folder in _scanner.FindSaveFolders(root))
            TryAdd(folder);

        if (_saves.Count > 0)
            SavesList.SelectedIndex = 0;
        else
            ResetDetails();

        Status(_saves.Count > 0
            ? $"Loaded {_saves.Count} save(s) from {root}"
            : "No PS3 saves found in selected folder.");
    }

    private void Browse_OnClick(object sender, RoutedEventArgs e)
    {
        if (_operationInProgress) return;
        var dialog = new OpenFolderDialog
        {
            Title = "Choose USB root, PS3 folder, SAVEDATA folder, or individual save",
            Multiselect = false
        };
        if (dialog.ShowDialog(this) == true)
            LoadRoot(dialog.FolderName);
    }

    private void ChangeProfile_OnClick(object sender, RoutedEventArgs e)
    {
        if (_operationInProgress) return;
        var dialog = new OpenFileDialog
        {
            Title = "Choose target user PARAM.SFO",
            Filter = "PS3 PARAM.SFO|PARAM.SFO|All files|*.*"
        };
        if (dialog.ShowDialog(this) != true) return;

        try
        {
            _sfo.Parse(dialog.FileName);
            _profilePath = dialog.FileName;
            _settings.SaveProfilePath(dialog.FileName);
            ApplyProfileDisplay(dialog.FileName);
            Status("User profile loaded and remembered.");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Profile PARAM.SFO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SavesList_OnSelectionChanged(object sender, SelectionChangedEventArgs e) => RefreshDetails();

    private void SavesList_OnPreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject source) return;
        if (ItemsControl.ContainerFromElement(SavesList, source) is ListViewItem item)
        {
            item.IsSelected = true;
            item.Focus();
        }
        else
        {
            SavesList.SelectedItem = null;
        }
    }

    private void RefreshDetails()
    {
        var save = Selected;
        if (save == null)
        {
            ResetDetails();
            return;
        }

        SelectedIcon.Source = save.Icon;
        SelectedTitle.Text = save.Title;
        SelectedDescription.Text = string.IsNullOrWhiteSpace(save.Description)
            ? Path.GetFileName(save.FolderPath)
            : save.Description;
        SelectedTitleId.Text = save.TitleId;
        InfoText.Text =
            $"Title ID        {save.TitleId}\n" +
            $"Save folder     {Path.GetFileName(save.FolderPath)}\n" +
            $"Location        {save.FolderPath}\n" +
            $"Region          {save.Region}";
        SecurityText.Text =
            $"Copy protected  {save.CopyProtected}\n" +
            $"PARAM.PFD       {(save.HasPfd ? "Present" : "Missing")}\n" +
            $"games.conf key  {(save.HasGameKey ? "Matched" : "Not found")}\n" +
            $"Second layer    {save.SecondLayer}";
        PayloadList.ItemsSource = save.PayloadFiles.Select(FormatPayload).ToArray();

        UpdateActionState();
        AppendBaseLog(save);
    }

    private static string FormatPayload(string path)
    {
        try
        {
            return $"{Path.GetFileName(path)}    ({new FileInfo(path).Length:N0} bytes)";
        }
        catch
        {
            return $"{Path.GetFileName(path)}    (unavailable)";
        }
    }

    private string? GetBestBackup(string saveFolder)
    {
        if (_lastBackup != null && _lastBackupTarget != null && File.Exists(_lastBackup)
            && Path.GetFullPath(_lastBackupTarget).Equals(Path.GetFullPath(saveFolder), StringComparison.OrdinalIgnoreCase))
            return _lastBackup;
        return _backups.FindBackups(saveFolder).FirstOrDefault();
    }

    private void ResetDetails()
    {
        SelectedIcon.Source = null;
        SelectedTitle.Text = "No save selected";
        SelectedDescription.Text = "Choose a PS3 save from the list";
        SelectedTitleId.Text = "";
        InfoText.Text = "Title ID        —\nSave folder     —\nLocation        —\nRegion          —";
        SecurityText.Text = "Copy protected  —\nPARAM.PFD       —\ngames.conf key  —\nSecond layer    —";
        PayloadList.ItemsSource = null;
        LogBox.Clear();
        UpdateActionState();
    }

    private void AppendBaseLog(SaveEntry save)
    {
        LogBox.Text =
            $"Game: {save.Title}\n" +
            $"Description: {save.Description}\n" +
            $"Title ID: {save.TitleId}\n" +
            $"Save folder: {Path.GetFileName(save.FolderPath)}\n" +
            $"Location: {save.FolderPath}\n" +
            $"PARAM.PFD: {(save.HasPfd ? "Present" : "Missing")}\n" +
            $"Copy protected: {save.CopyProtected}\n" +
            $"games.conf key: {(save.HasGameKey ? "Matched" : "Not found")}\n" +
            $"Second layer: {save.SecondLayer}\n\n" +
            "Payload files:\n" +
            string.Join("\n", save.PayloadFiles.Select(path => "  " + FormatPayload(path)));
    }

    private void AppendLog(string text)
    {
        LogBox.AppendText($"\n\n{new string('─', 42)}\n{text}\n");
        LogBox.ScrollToEnd();
    }

    private void Status(string text) => StatusText.Text = text;

    private bool TryBeginOperation(string status)
    {
        if (_operationInProgress)
        {
            Status("Another operation is already running.");
            return false;
        }

        _operationInProgress = true;
        BrowseButton.IsEnabled = false;
        ChangeProfileButton.IsEnabled = false;
        SavesList.IsEnabled = false;
        UpdateActionState();
        Status(status);
        return true;
    }

    private void EndOperation()
    {
        _operationInProgress = false;
        BrowseButton.IsEnabled = true;
        ChangeProfileButton.IsEnabled = true;
        SavesList.IsEnabled = true;
        UpdateActionState();
    }

    private void UpdateActionState()
    {
        var save = Selected;
        var canPfd = !_operationInProgress
            && save != null
            && !string.IsNullOrWhiteSpace(save.TitleId)
            && save.HasPfd
            && save.HasGameKey;

        DecryptButton.IsEnabled = canPfd && save!.PayloadFiles.Count > 0;
        EncryptButton.IsEnabled = canPfd && save!.PayloadFiles.Count > 0;
        CryptoButton.IsEnabled = !_operationInProgress && save?.PayloadFiles.Count > 0;

        if (save != null)
        {
            UndoButton.Content = "Undo Last Change\nRestore Backup";
            UndoButton.IsEnabled = !_operationInProgress && GetBestBackup(save.FolderPath) != null;
        }
        else
        {
            var canUndoDelete = _deletedBackup != null && File.Exists(_deletedBackup);
            UndoButton.Content = canUndoDelete
                ? "Undo Delete\nRestore Deleted Save"
                : "Undo Last Change\nRestore Backup";
            UndoButton.IsEnabled = !_operationInProgress && canUndoDelete;
        }
    }

    private bool EnsurePfdReady(SaveEntry save, bool requirePayload)
    {
        string? error = null;
        if (string.IsNullOrWhiteSpace(save.TitleId)) error = "The save Title ID could not be determined.";
        else if (!save.HasPfd) error = "PARAM.PFD is missing from this save.";
        else if (!save.HasGameKey) error = $"No secure_file_id entry was found for {save.TitleId} in games.conf.";
        else if (requirePayload && save.PayloadFiles.Count == 0) error = "No candidate save payload files were found.";

        if (error == null) return true;
        MessageBox.Show(this, error, "PS3 Save Manager", MessageBoxButton.OK, MessageBoxImage.Warning);
        return false;
    }

    private async void Decrypt_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || !EnsurePfdReady(save, requirePayload: true)) return;
        if (!TryBeginOperation("Decrypting PS3 secure layer…")) return;

        string? backup = null;
        try
        {
            backup = _backups.Create(save.FolderPath, "DECRYPT");
            _lastBackup = backup;
            _lastBackupTarget = save.FolderPath;

            var names = save.PayloadFiles.Select(Path.GetFileName).OfType<string>();
            var result = await _pfd.RunAsync(save.TitleId, "-d", save.FolderPath, names);
            if (!result.Success) throw new InvalidOperationException(result.Output);

            PfdToolService.CleanupMarkers(save.FolderPath);
            ReloadSelected();
            AppendLog(
                $"Decrypt Save\nBackup: {backup}\n\n" +
                $"PS3 layer decrypted: {save.PayloadFiles.Count} file(s)\n" +
                "Second layer: NOT CHANGED\nResult: COMPLETE\n\n" + result.Output);
            Status("Decrypt complete.");
        }
        catch (Exception ex)
        {
            if (backup != null && File.Exists(backup))
            {
                try { _backups.Restore(save.FolderPath, backup); ReloadSelected(); } catch { }
            }
            MessageBox.Show(this, ex.Message, "Decrypt failed", MessageBoxButton.OK, MessageBoxImage.Error);
            Status("Decrypt failed; rollback attempted.");
        }
        finally
        {
            EndOperation();
        }
    }

    private async void Encrypt_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || !EnsurePfdReady(save, requirePayload: true)) return;
        if (string.IsNullOrWhiteSpace(_profilePath) || !File.Exists(_profilePath))
        {
            MessageBox.Show(
                this,
                "Choose your user profile PARAM.SFO once. It will then be remembered and used automatically for Encrypt + Resign.",
                "Profile required",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }
        if (!TryBeginOperation("Applying remembered profile…")) return;

        string? backup = null;
        try
        {
            backup = _backups.Create(save.FolderPath, "ENCRYPT");
            _lastBackup = backup;
            _lastBackupTarget = save.FolderPath;

            var targetSfo = Path.Combine(save.FolderPath, "PARAM.SFO");
            var profileFields = _sfo.CopyOwnershipFields(_profilePath, targetSfo);

            Status("Encrypting + rebuilding PARAM.PFD…");
            var names = save.PayloadFiles.Select(Path.GetFileName).OfType<string>();
            var result = await _pfd.RunAsync(save.TitleId, "-e", save.FolderPath, names);
            if (!result.Success) throw new InvalidOperationException(result.Output);

            var check = await _pfd.RunAsync(save.TitleId, "-c", save.FolderPath);
            if (!check.Success)
                throw new InvalidOperationException("Post-encrypt verification failed.\n\n" + check.Output);

            PfdToolService.CleanupMarkers(save.FolderPath);
            ReloadSelected();
            AppendLog(
                $"Encrypt + Resign\nBackup: {backup}\n" +
                $"Target profile: {ProfileIdText.Text}\nOwnership fields copied: {profileFields}\n\n" +
                "PS3/PFD encryption: OK\nPARAM.PFD verification: OK\n" +
                "Result: SAVE ENCRYPTED, RESIGNED AND VERIFIED\n\n" + check.Output);
            Status("Encrypt + resign + verify complete.");
        }
        catch (Exception ex)
        {
            if (backup != null && File.Exists(backup))
            {
                try { _backups.Restore(save.FolderPath, backup); ReloadSelected(); } catch { }
            }
            MessageBox.Show(this, ex.Message, "Encrypt failed", MessageBoxButton.OK, MessageBoxImage.Error);
            Status("Encrypt failed; rollback attempted.");
        }
        finally
        {
            EndOperation();
        }
    }

    private async void Verify_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || !EnsurePfdReady(save, requirePayload: false)) return;
        if (!TryBeginOperation("Verifying PARAM.PFD…")) return;

        try
        {
            var result = await _pfd.RunAsync(save.TitleId, "-c", save.FolderPath);
            AppendLog($"Verification\n{(result.Success ? "Result: SAVE VALID" : "Result: VERIFY FAILED")}\n\n{result.Output}");
            Status(result.Success ? "Save verified." : "Verification failed.");
            if (!result.Success)
                MessageBox.Show(this, result.Output, "Verification failed", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            EndOperation();
        }
    }

    private void Undo_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null)
        {
            UndoDeletedSave();
            return;
        }

        var backup = GetBestBackup(save.FolderPath);
        if (backup == null || !File.Exists(backup)) return;
        if (MessageBox.Show(
                this,
                $"Restore this save from backup?\n\n{backup}",
                "Undo Last Change",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;
        if (!TryBeginOperation("Restoring backup…")) return;

        try
        {
            var safety = _backups.Create(save.FolderPath, "UNDO_SAFETY");
            var count = _backups.Restore(save.FolderPath, backup);
            _lastBackup = null;
            _lastBackupTarget = null;
            ReloadSelected();
            AppendLog($"Undo Last Change\nFiles restored: {count}\nBackup: {backup}\nSafety snapshot: {safety}\nResult: RESTORED");
            Status("Undo complete.");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Undo failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            EndOperation();
        }
    }

    private void UndoDeletedSave()
    {
        if (_deletedBackup == null || _deletedParent == null || _deletedFolderName == null || !File.Exists(_deletedBackup))
            return;
        var target = Path.Combine(_deletedParent, _deletedFolderName);
        if (Directory.Exists(target))
        {
            MessageBox.Show(this, "The original save folder already exists, so it will not be overwritten.", "Undo Delete", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!TryBeginOperation("Restoring deleted save…")) return;

        try
        {
            _backups.Restore(target, _deletedBackup);
            UpsertEntry(target);
            _deletedBackup = _deletedParent = _deletedFolderName = null;
            Status("Deleted save restored.");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Undo Delete failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            EndOperation();
        }
    }

    private void CryptoLab_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || _operationInProgress) return;
        new CryptoLabWindow(save.PayloadFiles) { Owner = this }.ShowDialog();
    }

    private void CopyLog_OnClick(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrEmpty(LogBox.Text)) return;
        Clipboard.SetText(LogBox.Text);
        Status("Operation log copied.");
    }

    private void OpenFolder_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || !Directory.Exists(save.FolderPath)) return;
        OpenExplorer(save.FolderPath);
    }

    private async void Refresh_OnClick(object sender, RoutedEventArgs e)
    {
        if (_operationInProgress) return;
        if (_currentRoot != null)
            LoadRoot(_currentRoot);
        else
            await ScanUsbAsync();
    }

    private void CopySave_OnClick(object sender, RoutedEventArgs e)
    {
        if (Selected == null || _operationInProgress) return;
        _copiedSave = Selected.FolderPath;
        Status($"Copied save: {Path.GetFileName(_copiedSave)}");
    }

    private void PasteSave_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || _copiedSave == null || !Directory.Exists(_copiedSave)) return;

        var parent = Directory.GetParent(save.FolderPath)?.FullName
            ?? throw new InvalidOperationException("Save folder has no parent directory.");
        var destination = Path.Combine(parent, Path.GetFileName(_copiedSave));
        if (Path.GetFullPath(destination).Equals(Path.GetFullPath(_copiedSave), StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show(this, "Source and destination are the same SAVEDATA folder.");
            return;
        }
        if (!TryBeginOperation("Pasting save…")) return;

        try
        {
            string? replaceBackup = null;
            if (Directory.Exists(destination))
            {
                if (MessageBox.Show(
                        this,
                        $"{Path.GetFileName(destination)} already exists. Replace it?\n\nA backup will be created first.",
                        "Paste Save",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Warning) != MessageBoxResult.Yes)
                    return;

                replaceBackup = _backups.Create(destination, "PASTE_REPLACE");
                Directory.Delete(destination, recursive: true);
            }

            try
            {
                CopyDirectory(_copiedSave, destination);
                if (!File.Exists(Path.Combine(destination, "PARAM.SFO")) || !File.Exists(Path.Combine(destination, "PARAM.PFD")))
                    throw new InvalidDataException("Copied save is missing PARAM.SFO or PARAM.PFD.");
            }
            catch
            {
                if (Directory.Exists(destination)) Directory.Delete(destination, recursive: true);
                if (replaceBackup != null) _backups.Restore(destination, replaceBackup);
                throw;
            }

            UpsertEntry(destination);
            Status($"Pasted save: {Path.GetFileName(destination)}");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Paste failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            EndOperation();
        }
    }

    private void DeleteSave_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null) return;
        if (MessageBox.Show(
                this,
                $"Delete this PS3 save?\n\n{save.Title}\n{save.FolderPath}\n\nA verified backup will be created first.",
                "Delete Save",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;
        if (!TryBeginOperation("Backing up save before deletion…")) return;

        string? backup = null;
        try
        {
            backup = _backups.Create(save.FolderPath, "DELETE");
            var parent = Directory.GetParent(save.FolderPath)?.FullName
                ?? throw new InvalidOperationException("Save folder has no parent directory.");
            var name = Path.GetFileName(save.FolderPath);
            Directory.Delete(save.FolderPath, recursive: true);
            _saves.Remove(save);
            _deletedBackup = backup;
            _deletedParent = parent;
            _deletedFolderName = name;
            ResetDetails();
            Status($"Deleted save. Undo Delete is available. Recovery backup: {backup}");
        }
        catch (Exception ex)
        {
            if (backup != null && File.Exists(backup) && !Directory.Exists(save.FolderPath))
            {
                try { _backups.Restore(save.FolderPath, backup); } catch { }
            }
            MessageBox.Show(this, ex.Message, "Delete failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            EndOperation();
        }
    }

    private void OpenBackups_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null) return;
        var parent = Directory.GetParent(save.FolderPath)?.FullName;
        if (parent == null) return;
        var directory = Path.Combine(parent, "PS3_Save_Manager_Backups");
        Directory.CreateDirectory(directory);
        OpenExplorer(directory);
    }

    private async void ResignOnly_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || !EnsurePfdReady(save, requirePayload: false)) return;
        if (string.IsNullOrWhiteSpace(_profilePath) || !File.Exists(_profilePath))
        {
            MessageBox.Show(this, "Choose your user profile PARAM.SFO first.", "Profile required", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!TryBeginOperation("Resigning save…")) return;

        string? backup = null;
        try
        {
            backup = _backups.Create(save.FolderPath, "RESIGN");
            var copied = _sfo.CopyOwnershipFields(_profilePath, Path.Combine(save.FolderPath, "PARAM.SFO"));
            var update = await _pfd.RunAsync(save.TitleId, "-u", save.FolderPath);
            if (!update.Success) throw new InvalidOperationException(update.Output);
            var verify = await _pfd.RunAsync(save.TitleId, "-c", save.FolderPath);
            if (!verify.Success) throw new InvalidOperationException("Verification failed.\n\n" + verify.Output);

            _lastBackup = backup;
            _lastBackupTarget = save.FolderPath;
            ReloadSelected();
            AppendLog($"Resign Only\nTarget profile: {ProfileIdText.Text}\nOwnership fields copied: {copied}\nPARAM.PFD update: OK\nVerification: OK");
            Status("Save resigned to remembered profile and verified.");
        }
        catch (Exception ex)
        {
            if (backup != null && File.Exists(backup))
            {
                try { _backups.Restore(save.FolderPath, backup); ReloadSelected(); } catch { }
            }
            MessageBox.Show(this, ex.Message, "Resign failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            EndOperation();
        }
    }

    private async void RemoveCopyProtection_OnClick(object sender, RoutedEventArgs e)
    {
        var save = Selected;
        if (save == null || !EnsurePfdReady(save, requirePayload: false)) return;
        if (!TryBeginOperation("Removing copy protection…")) return;

        string? backup = null;
        try
        {
            backup = _backups.Create(save.FolderPath, "COPYPROTECT");
            var sfoPath = Path.Combine(save.FolderPath, "PARAM.SFO");
            var metadata = _sfo.Parse(sfoPath);
            if (!metadata.TryGetValue("ATTRIBUTE", out var raw) || !uint.TryParse(raw, out var attribute))
                throw new InvalidDataException("ATTRIBUTE field is unavailable.");

            _sfo.SetUInt32(sfoPath, "ATTRIBUTE", attribute & ~1u);
            var update = await _pfd.RunAsync(save.TitleId, "-u", save.FolderPath);
            if (!update.Success) throw new InvalidOperationException(update.Output);
            var verify = await _pfd.RunAsync(save.TitleId, "-c", save.FolderPath);
            if (!verify.Success) throw new InvalidOperationException("Verification failed.\n\n" + verify.Output);

            _lastBackup = backup;
            _lastBackupTarget = save.FolderPath;
            ReloadSelected();
            Status("Copy protection removed and PFD updated.");
        }
        catch (Exception ex)
        {
            if (backup != null && File.Exists(backup))
            {
                try { _backups.Restore(save.FolderPath, backup); ReloadSelected(); } catch { }
            }
            MessageBox.Show(this, ex.Message, "Remove Copy Protection failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            EndOperation();
        }
    }

    private static void OpenExplorer(string path)
    {
        var startInfo = new ProcessStartInfo("explorer.exe") { UseShellExecute = true };
        startInfo.ArgumentList.Add(path);
        Process.Start(startInfo);
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var file in Directory.GetFiles(source))
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), overwrite: true);
        foreach (var directory in Directory.GetDirectories(source))
            CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }

    private void ReloadSelected()
    {
        var old = Selected;
        if (old == null) return;
        var index = SavesList.SelectedIndex;
        if (index < 0 || index >= _saves.Count) return;

        try
        {
            var fresh = _scanner.Load(old.FolderPath);
            _saves[index] = fresh;
            SavesList.SelectedIndex = index;
            RefreshDetails();
        }
        catch (Exception ex)
        {
            AppendLog("Refresh failed: " + ex.Message);
        }
    }
}
