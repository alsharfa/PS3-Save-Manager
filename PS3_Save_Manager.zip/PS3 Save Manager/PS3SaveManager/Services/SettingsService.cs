using System.Text.Json;

namespace PS3SaveManager.Services;

public sealed class SettingsService
{
    private readonly string _path;

    public SettingsService()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "PS3 Save Manager");
        Directory.CreateDirectory(dir);
        _path = Path.Combine(dir, "settings.json");
    }

    public string? LoadProfilePath()
    {
        try
        {
            if (!File.Exists(_path)) return null;
            using var document = JsonDocument.Parse(File.ReadAllText(_path));
            return document.RootElement.TryGetProperty("profile_sfo", out var value)
                ? value.GetString()
                : null;
        }
        catch
        {
            return null;
        }
    }

    public void SaveProfilePath(string path)
    {
        var json = JsonSerializer.Serialize(
            new Dictionary<string, string> { ["profile_sfo"] = path },
            new JsonSerializerOptions { WriteIndented = true });

        var temp = _path + ".tmp";
        File.WriteAllText(temp, json);
        File.Move(temp, _path, true);
    }
}
