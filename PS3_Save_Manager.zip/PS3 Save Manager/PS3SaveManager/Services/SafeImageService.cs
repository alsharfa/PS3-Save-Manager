using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PS3SaveManager.Services;

/// <summary>
/// Loads save artwork without leaving deferred WPF image decoding behind.
/// Some PS3 ICON0.PNG files contain PNG variants/pixel formats that WPF cannot
/// render. Those images must fail closed (null) instead of crashing the UI when
/// a virtualized ListView row is realized during scrolling.
/// </summary>
public static class SafeImageService
{
    public static ImageSource? TryLoad(string path, int decodePixelWidth = 220)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            return null;

        try
        {
            using var stream = new FileStream(
                path,
                FileMode.Open,
                FileAccess.Read,
                FileShare.ReadWrite | FileShare.Delete);

            // Decoder + OnLoad forces all file IO and decoding to happen here,
            // while we're inside the exception boundary. It prevents WPF from
            // attempting deferred decode later when the user scrolls the list.
            var decoder = BitmapDecoder.Create(
                stream,
                BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile,
                BitmapCacheOption.OnLoad);

            if (decoder.Frames.Count == 0)
                return null;

            BitmapSource source = decoder.Frames[0];

            // Normalize to a WPF-safe 32-bit format. A source may decode but
            // still expose an exotic pixel format that fails when rendered.
            if (source.Format != PixelFormats.Bgra32 &&
                source.Format != PixelFormats.Pbgra32 &&
                source.Format != PixelFormats.Bgr32)
            {
                var converted = new FormatConvertedBitmap();
                converted.BeginInit();
                converted.Source = source;
                converted.DestinationFormat = PixelFormats.Pbgra32;
                converted.EndInit();
                converted.Freeze();
                source = converted;
            }

            if (decodePixelWidth > 0 && source.PixelWidth > decodePixelWidth)
            {
                var scale = (double)decodePixelWidth / source.PixelWidth;
                var scaled = new TransformedBitmap(source, new ScaleTransform(scale, scale));
                scaled.Freeze();
                source = scaled;
            }

            // Copy pixels into a new in-memory BitmapSource. This deliberately
            // severs the final image from the decoder/stream and catches pixel
            // format failures before it reaches an Image control.
            int stride = (source.PixelWidth * source.Format.BitsPerPixel + 7) / 8;
            var pixels = new byte[stride * source.PixelHeight];
            source.CopyPixels(pixels, stride, 0);

            var safe = BitmapSource.Create(
                source.PixelWidth,
                source.PixelHeight,
                source.DpiX > 0 ? source.DpiX : 96,
                source.DpiY > 0 ? source.DpiY : 96,
                source.Format,
                null,
                pixels,
                stride);
            safe.Freeze();
            return safe;
        }
        catch (Exception) when (
            // Bad/corrupt/unsupported save artwork should never take down the
            // manager. The save itself remains usable without a thumbnail.
            true)
        {
            return null;
        }
    }
}
