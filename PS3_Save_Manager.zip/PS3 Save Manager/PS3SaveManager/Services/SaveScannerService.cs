using System.Text.RegularExpressions;
using PS3SaveManager.Models;
namespace PS3SaveManager.Services;
public sealed class SaveScannerService
{
    private static readonly HashSet<string> Skip=new(StringComparer.OrdinalIgnoreCase){"PARAM.SFO","PARAM.PFD","ICON0.PNG","ICON1.PAM","PIC1.PNG","SND0.AT3","~FILES_DECRYPTED_BY_PFDTOOL.TXT","~FILES_ENCRYPTED_BY_PFDTOOL.TXT"};
    private readonly SfoService _sfo; private readonly GameConfigService _games;
    public SaveScannerService(SfoService sfo,GameConfigService games){_sfo=sfo;_games=games;}
    public IEnumerable<string> CandidateUsbRoots()
    {
        var roots = new List<string>();
        foreach(var d in DriveInfo.GetDrives())
        {
            try
            {
                if(d.IsReady && (d.DriveType==DriveType.Removable || Directory.Exists(Path.Combine(d.RootDirectory.FullName,"PS3","SAVEDATA"))))
                    roots.Add(d.RootDirectory.FullName);
            }
            catch
            {
                // Ignore inaccessible/unready drives and continue scanning.
            }
        }
        return roots;
    }
    public IReadOnlyList<string> FindSaveFolders(string root)
    {
        var result=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if(File.Exists(Path.Combine(root,"PARAM.SFO"))) result.Add(root);
        var candidates=new List<string>();
        var name=new DirectoryInfo(root).Name;
        if(name.Equals("SAVEDATA",StringComparison.OrdinalIgnoreCase)) candidates.Add(root);
        if(name.Equals("PS3",StringComparison.OrdinalIgnoreCase)) candidates.Add(Path.Combine(root,"SAVEDATA"));
        candidates.Add(Path.Combine(root,"PS3","SAVEDATA")); candidates.Add(Path.Combine(root,"SAVEDATA"));
        foreach(var c in candidates.Where(Directory.Exists))
            foreach(var d in Directory.EnumerateDirectories(c)) if(File.Exists(Path.Combine(d,"PARAM.SFO"))) result.Add(d);
        if(result.Count==0 && Directory.Exists(root))
        {
            try
            {
                foreach(var d in Directory.EnumerateDirectories(root,"SAVEDATA",SearchOption.AllDirectories))
                {
                    var rel=Path.GetRelativePath(root,d); if(rel.Split(Path.DirectorySeparatorChar).Length>4) continue;
                    foreach(var s in Directory.EnumerateDirectories(d)) if(File.Exists(Path.Combine(s,"PARAM.SFO"))) result.Add(s);
                }
            } catch { }
        }
        return result.OrderBy(x=>Path.GetFileName(x),StringComparer.OrdinalIgnoreCase).ToArray();
    }
    public SaveEntry Load(string folder)
    {
        var meta=_sfo.Parse(Path.Combine(folder,"PARAM.SFO"));
        string source=(meta.TryGetValue("SAVEDATA_DIRECTORY",out var sd)?sd:"")+" "+Path.GetFileName(folder);
        var m=Regex.Match(source.ToUpperInvariant(),"([A-Z]{4}\\d{5})"); string tid=m.Success?m.Groups[1].Value:"";
        string title=meta.TryGetValue("TITLE",out var t)&&!string.IsNullOrWhiteSpace(t)?t:Path.GetFileName(folder);
        string desc=(meta.TryGetValue("SUB_TITLE",out var st)?st:null) ?? (meta.TryGetValue("DETAIL",out var de)?de:null) ?? "";
        string cp="Unknown"; if(meta.TryGetValue("ATTRIBUTE",out var a)&&int.TryParse(a,out var av))cp=(av&1)!=0?"Yes":"No";
        var payload=Directory.EnumerateFiles(folder).Where(p=>IsPayloadCandidate(p)).ToArray();
        var iconPath=Path.Combine(folder,"ICON0.PNG");
        var icon=SafeImageService.TryLoad(iconPath,220);
        string layer="None";
        if(payload.Length>0)
        {
            try
            {
                var lab=new CryptoLabService();
                var analyses=payload.Select(lab.Analyze).ToArray();
                if(analyses.Any(x=>x.Magic is "GZip" or "ZIP")) layer="Wrapper / compressed";
                else if(analyses.Any(x=>x.Entropy>7.85)) layer="High entropy";
                else layer="Binary / structured";
            }
            catch { layer="Unknown"; }
        }
        return new SaveEntry{FolderPath=folder,Title=title,Description=desc,TitleId=tid,Region=RegionFromTitleId(tid),CopyProtected=cp,HasPfd=File.Exists(Path.Combine(folder,"PARAM.PFD")),HasGameKey=_games.Lookup(tid)!=null,SecondLayer=layer,PayloadFiles=payload,Icon=icon};
    }

    private static bool IsPayloadCandidate(string path)
    {
        var name=Path.GetFileName(path);
        if(Skip.Contains(name)||name.StartsWith('~'))return false;
        if(name.EndsWith(".decoded",StringComparison.OrdinalIgnoreCase))return false;
        return true;
    }

    public static string RegionFromTitleId(string tid)
    {
        tid=tid.ToUpperInvariant();
        if(tid.StartsWith("BLES")||tid.StartsWith("BCES")||tid.StartsWith("NPEB"))return "Europe (PAL)";
        if(tid.StartsWith("BLUS")||tid.StartsWith("BCUS")||tid.StartsWith("NPUB"))return "North America";
        if(tid.StartsWith("BLJS")||tid.StartsWith("BLJM")||tid.StartsWith("BCJS")||tid.StartsWith("NPJB"))return "Japan";
        if(tid.StartsWith("BLAS")||tid.StartsWith("BCAS")||tid.StartsWith("BLKS"))return "Asia";
        return "Unknown / Not specified";
    }
}
