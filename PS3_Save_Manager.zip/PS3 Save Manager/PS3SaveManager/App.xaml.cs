using System.Windows;
namespace PS3SaveManager;
public partial class App : Application { }
