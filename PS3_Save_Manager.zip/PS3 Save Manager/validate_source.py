from pathlib import Path
import json, re, sys, xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
proj=root/'PS3SaveManager'
problems=[]

# XML/XAML/project integrity.
for p in list(proj.rglob('*.xaml'))+[proj/'PS3SaveManager.csproj']:
    try: ET.parse(p)
    except Exception as e: problems.append(f'XML {p}: {e}')

# XAML event handlers must exist in code-behind.
event_names=('Click','Loaded','SelectionChanged','PreviewMouseRightButtonDown')
for xaml in proj.rglob('*.xaml'):
    cs=Path(str(xaml)+'.cs')
    if not cs.exists():
        continue
    xt=xaml.read_text(encoding='utf-8')
    ct=cs.read_text(encoding='utf-8')
    handlers=set()
    for event in event_names:
        handlers.update(re.findall(rf'{event}="([^"]+)"',xt))
    methods=set(re.findall(r'\b(?:void|Task)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(',ct))
    for h in sorted(handlers-methods):
        problems.append(f'Missing handler {h} for {xaml.name}')

# Lightweight lexical C# sanity.
for p in proj.rglob('*.cs'):
    s=p.read_text(encoding='utf-8')
    t=re.sub(r'@"(?:[^"]|"")*"','""',s,flags=re.S)
    t=re.sub(r'\$?"(?:\\.|[^"\\])*"','""',t,flags=re.S)
    t=re.sub(r"'(?:\\.|[^'\\])'","''",t)
    t=re.sub(r'//.*','',t); t=re.sub(r'/\*.*?\*/','',t,flags=re.S)
    bal=0
    for c in t:
        if c=='{': bal+=1
        elif c=='}': bal-=1
        if bal<0:
            problems.append(f'Negative brace balance in {p.name}')
            break
    if bal: problems.append(f'Brace imbalance {bal} in {p.name}')

# Runtime resources and config files.
for rel in ['pfdtool.exe','Config/games.conf','Config/global.conf','Config/second_layer_rules.json','Config/checksum_rules.json','Assets/app_icon.ico','Assets/ps3_save_manager_logo.png']:
    if not (proj/rel).exists(): problems.append('Missing '+rel)

for rel in ['Config/second_layer_rules.json','Config/checksum_rules.json']:
    try: json.loads((proj/rel).read_text(encoding='utf-8'))
    except Exception as e: problems.append(f'Invalid JSON {rel}: {e}')

games=(proj/'Config/games.conf').read_text(encoding='utf-8',errors='ignore')
if '[BLES01897]' not in games or '424C45532D3031383937000000000000' not in games:
    problems.append('BLES01897 secure_file_id is missing or changed')

global_conf=(proj/'Config/global.conf').read_text(encoding='utf-8',errors='ignore')
if 'console_id=00000000000000000000000000000000' not in global_conf:
    problems.append('console_id is not the requested all-zero value')

# Product branding / packaging.
main=(proj/'MainWindow.xaml').read_text(encoding='utf-8')
if 'Title="PS3 Save Manager"' not in main: problems.append('Main window title is not exactly PS3 Save Manager')
if re.search(r'v1\.0\.\d| - WPF',main): problems.append('Stale version/WPF branding remains in MainWindow.xaml')

csproj=(proj/'PS3SaveManager.csproj').read_text(encoding='utf-8')
if '<CopyToPublishDirectory>PreserveNewest</CopyToPublishDirectory>' not in csproj:
    problems.append('Runtime content is not explicitly copied during publish')

build=(root/'BUILD_X64.cmd').read_text(encoding='utf-8',errors='ignore')
if '"PS3 Save Manager.sln"' not in build: problems.append('BUILD_X64 does not target renamed solution')
if '-p:Platform=x64' in build: problems.append('BUILD_X64 requests undefined x64 solution platform')

if problems:
    print('VALIDATION FAILED')
    print('\n'.join(problems))
    sys.exit(1)

print('VALIDATION PASS')
print('Product name: PS3 Save Manager')
print('XAML/project XML parsed')
print('Event handlers resolved')
print('C# lexical braces balanced')
print('Required runtime/config files present')
print('Config JSON parsed')
print('BLES01897 secure_file_id verified')
print('global.conf console_id verified as 32 zeroes')
print('Publish content rules verified')
print('Build-script solution path verified')
