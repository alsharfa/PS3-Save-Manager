namespace PS3SaveManager.Models;
public sealed record CryptoAnalysis(string FileName,long Size,double Entropy,string Classification,string Magic,int PrintablePercent,IReadOnlyList<string> Notes);
