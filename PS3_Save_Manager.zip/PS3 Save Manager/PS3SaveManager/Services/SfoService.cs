using System.Buffers.Binary;
using System.Text;

namespace PS3SaveManager.Services;

public sealed class SfoService
{
    private sealed record Entry(string Key,ushort Format,int HeaderOffset,int DataOffset,int Length,int MaxLength);

    public Dictionary<string,string> Parse(string path)
    {
        var b=File.ReadAllBytes(path);
        var entries=ReadEntries(b);
        var output=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        foreach(var e in entries)
        {
            var raw=b.AsSpan(e.DataOffset,e.Length);
            string value;
            if(e.Format==0x0404 && raw.Length>=4)value=BinaryPrimitives.ReadUInt32LittleEndian(raw[..4]).ToString();
            else
            {
                int n=raw.IndexOf((byte)0);if(n<0)n=raw.Length;
                value=Encoding.UTF8.GetString(raw[..n]);
            }
            output[e.Key]=value;
        }
        return output;
    }

    public int CopyOwnershipFields(string profileSfo,string targetSfo)
    {
        var source=File.ReadAllBytes(profileSfo);
        var target=File.ReadAllBytes(targetSfo);
        var srcEntries=ReadEntries(source).ToDictionary(x=>x.Key,StringComparer.OrdinalIgnoreCase);
        var dstEntries=ReadEntries(target).ToDictionary(x=>x.Key,StringComparer.OrdinalIgnoreCase);
        var fields=new[]{"ACCOUNT_ID","PARAMS","PARAMS2"};
        int copied=0;

        foreach(var key in fields)
        {
            if(!srcEntries.TryGetValue(key,out var s)||!dstEntries.TryGetValue(key,out var d))continue;
            if(s.Length>d.MaxLength)throw new InvalidDataException($"Profile field {key} is larger than the target PARAM.SFO field capacity.");
            Array.Clear(target,d.DataOffset,d.MaxLength);
            Buffer.BlockCopy(source,s.DataOffset,target,d.DataOffset,s.Length);
            BinaryPrimitives.WriteUInt32LittleEndian(target.AsSpan(d.HeaderOffset+4,4),(uint)s.Length);
            copied++;
        }
        if(copied==0)throw new InvalidDataException("No compatible ownership fields (ACCOUNT_ID/PARAMS/PARAMS2) were found in both PARAM.SFO files.");
        File.WriteAllBytes(targetSfo,target);
        _=Parse(targetSfo);
        return copied;
    }

    public void SetUInt32(string path,string fieldName,uint value)
    {
        var b=File.ReadAllBytes(path);
        var e=ReadEntries(b).FirstOrDefault(x=>x.Key.Equals(fieldName,StringComparison.OrdinalIgnoreCase))
            ?? throw new KeyNotFoundException($"{fieldName} was not found in PARAM.SFO.");
        if(e.Format!=0x0404||e.Length<4)throw new InvalidDataException($"{fieldName} is not a 32-bit integer field.");
        BinaryPrimitives.WriteUInt32LittleEndian(b.AsSpan(e.DataOffset,4),value);
        File.WriteAllBytes(path,b);
    }

    private static List<Entry> ReadEntries(byte[] b)
    {
        if(b.Length<20||b[0]!=0||b[1]!=(byte)'P'||b[2]!=(byte)'S'||b[3]!=(byte)'F')throw new InvalidDataException("Invalid PARAM.SFO");
        uint keyOff=BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(8,4));
        uint dataOff=BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(12,4));
        uint count=BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(16,4));
        var list=new List<Entry>();
        for(int i=0;i<count;i++)
        {
            int o=20+i*16;if(o+16>b.Length)break;
            ushort keyRel=BinaryPrimitives.ReadUInt16LittleEndian(b.AsSpan(o,2));
            ushort fmt=BinaryPrimitives.ReadUInt16LittleEndian(b.AsSpan(o+2,2));
            uint len=BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(o+4,4));
            uint maxLen=BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(o+8,4));
            uint dataRel=BinaryPrimitives.ReadUInt32LittleEndian(b.AsSpan(o+12,4));
            int ks=checked((int)keyOff+keyRel);if(ks<0||ks>=b.Length)continue;
            int ke=ks;while(ke<b.Length&&b[ke]!=0)ke++;
            string key=Encoding.UTF8.GetString(b,ks,ke-ks);
            int ds=checked((int)dataOff+(int)dataRel);if(ds<0||ds>=b.Length)continue;
            int safeMax=(int)Math.Min(maxLen,(uint)(b.Length-ds));
            int safeLen=(int)Math.Min(len,(uint)safeMax);
            list.Add(new Entry(key,fmt,o,ds,safeLen,safeMax));
        }
        return list;
    }
}
