using System.IO.Compression;
using System.Text;
using PS3SaveManager.Models;

namespace PS3SaveManager.Services;

public sealed class CryptoLabService
{
    private const int AnalysisSampleLimit = 16 * 1024 * 1024;
    private const long DecodeOutputLimit = 512L * 1024 * 1024;

    public CryptoAnalysis Analyze(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        var size = stream.Length;
        var sampleLength = (int)Math.Min(size, AnalysisSampleLimit);
        var data = new byte[sampleLength];
        var offset = 0;
        while (offset < data.Length)
        {
            var read = stream.Read(data, offset, data.Length - offset);
            if (read == 0) break;
            offset += read;
        }
        if (offset != data.Length) Array.Resize(ref data, offset);

        var entropy = Entropy(data);
        var printable = data.Length == 0
            ? 0
            : (int)Math.Round(data.Count(b => b is >= 32 and <= 126 || b is 9 or 10 or 13) * 100.0 / data.Length);
        var magic = Magic(data);
        var classification = entropy > 7.85
            ? "High entropy / likely encrypted or compressed"
            : entropy > 6.5
                ? "Packed or mixed binary"
                : "Structured / lower entropy";

        var notes = new List<string>();
        if (size % 16 == 0) notes.Add("Length is AES-block aligned (16 bytes).");
        if (printable > 65) notes.Add("High printable-text ratio.");
        if (magic != "Unknown") notes.Add($"Recognized container/header: {magic}.");
        if (size > AnalysisSampleLimit) notes.Add($"Entropy/printable analysis sampled the first {AnalysisSampleLimit:N0} bytes.");

        return new(Path.GetFileName(path), size, entropy, classification, magic, printable, notes);
    }

    public string? DecodeKnownLayer(string path, string outputPath)
    {
        var data = File.ReadAllBytes(path);
        try
        {
            if (data.Length >= 2 && data[0] == 0x1F && data[1] == 0x8B)
            {
                using var input = new MemoryStream(data);
                using var gzip = new GZipStream(input, CompressionMode.Decompress);
                using var output = File.Create(outputPath);
                CopyWithLimit(gzip, output);
                return "GZip decompressed";
            }

            if (data.Length >= 2 && data[0] == 0x78)
            {
                using var input = new MemoryStream(data);
                using var zlib = new ZLibStream(input, CompressionMode.Decompress);
                using var output = File.Create(outputPath);
                CopyWithLimit(zlib, output);
                return "zlib decompressed";
            }

            var text = Encoding.ASCII.GetString(data).Trim();
            if (text.Length >= 16
                && text.Length % 4 == 0
                && text.All(c => char.IsLetterOrDigit(c) || c is '+' or '/' or '=' or '\r' or '\n'))
            {
                var raw = Convert.FromBase64String(text);
                if (raw.LongLength > DecodeOutputLimit)
                    throw new InvalidDataException("Decoded output exceeds the 512 MiB safety limit.");
                File.WriteAllBytes(outputPath, raw);
                return "Base64 decoded";
            }
        }
        catch
        {
            try { if (File.Exists(outputPath)) File.Delete(outputPath); } catch { }
            return null;
        }

        return null;
    }

    private static void CopyWithLimit(Stream input, Stream output)
    {
        var buffer = new byte[128 * 1024];
        long total = 0;
        while (true)
        {
            var read = input.Read(buffer, 0, buffer.Length);
            if (read == 0) break;
            total += read;
            if (total > DecodeOutputLimit)
                throw new InvalidDataException("Decoded output exceeds the 512 MiB safety limit.");
            output.Write(buffer, 0, read);
        }
    }

    private static double Entropy(byte[] data)
    {
        if (data.Length == 0) return 0;
        Span<int> frequency = stackalloc int[256];
        foreach (var b in data) frequency[b]++;
        double entropy = 0;
        foreach (var count in frequency)
        {
            if (count == 0) continue;
            var probability = (double)count / data.Length;
            entropy -= probability * Math.Log2(probability);
        }
        return entropy;
    }

    private static string Magic(byte[] data)
    {
        if (data.Length >= 4 && data[0] == 0x50 && data[1] == 0x4B) return "ZIP";
        if (data.Length >= 2 && data[0] == 0x1F && data[1] == 0x8B) return "GZip";
        if (data.Length >= 4 && data[0] == 0x7F && data[1] == (byte)'E' && data[2] == (byte)'L' && data[3] == (byte)'F') return "ELF";
        if (data.Length >= 4 && Encoding.ASCII.GetString(data, 0, 4) == "KHSQ") return "KHSQ";
        if (data.Length >= 4 && Encoding.ASCII.GetString(data, 0, 4) == "GUMI") return "GUMI";
        return "Unknown";
    }
}
