using System.IO.Compression;

namespace PS3SaveManager.Services;

public sealed class BackupService
{
    public string Create(string saveFolder, string label)
    {
        if (!Directory.Exists(saveFolder))
            throw new DirectoryNotFoundException(saveFolder);

        var parent = Directory.GetParent(saveFolder)?.FullName
            ?? throw new InvalidOperationException("Save folder has no parent directory.");
        var backupDir = Path.Combine(parent, "PS3_Save_Manager_Backups");
        Directory.CreateDirectory(backupDir);

        var safeLabel = string.Concat(label.Select(c =>
            char.IsLetterOrDigit(c) || c is '-' or '_' ? c : '_'));
        var name = $"{Path.GetFileName(saveFolder)}_{safeLabel}_{DateTime.Now:yyyyMMdd_HHmmss_fff}_{Guid.NewGuid():N}.zip";
        var path = Path.Combine(backupDir, name);

        using (var zip = ZipFile.Open(path, ZipArchiveMode.Create))
        {
            foreach (var file in Directory.EnumerateFiles(saveFolder, "*", SearchOption.AllDirectories))
            {
                var relative = Path.GetRelativePath(parent, file);
                zip.CreateEntryFromFile(file, relative, CompressionLevel.Optimal);
            }
        }

        Validate(path, Path.GetFileName(saveFolder));
        return path;
    }

    public int Restore(string saveFolder, string zipPath)
    {
        if (!File.Exists(zipPath))
            throw new FileNotFoundException("Backup archive not found.", zipPath);

        var parent = Directory.GetParent(saveFolder)?.FullName
            ?? throw new InvalidOperationException("Save folder has no parent directory.");
        var expectedRoot = Path.GetFileName(saveFolder);
        var count = Validate(zipPath, expectedRoot);

        var safety = saveFolder + ".restore_pending_" + Guid.NewGuid().ToString("N");
        if (Directory.Exists(saveFolder))
            Directory.Move(saveFolder, safety);

        try
        {
            ZipFile.ExtractToDirectory(zipPath, parent, overwriteFiles: false);
            if (!Directory.Exists(saveFolder))
                throw new InvalidDataException("Backup did not restore the expected save folder.");

            if (Directory.Exists(safety))
                Directory.Delete(safety, recursive: true);
            return count;
        }
        catch
        {
            try
            {
                if (Directory.Exists(saveFolder))
                    Directory.Delete(saveFolder, recursive: true);
                if (Directory.Exists(safety))
                    Directory.Move(safety, saveFolder);
            }
            catch
            {
                // Preserve the original exception; the safety folder remains for manual recovery.
            }
            throw;
        }
    }

    public IReadOnlyList<string> FindBackups(string saveFolder)
    {
        var parent = Directory.GetParent(saveFolder)?.FullName;
        if (parent == null) return Array.Empty<string>();

        var dir = Path.Combine(parent, "PS3_Save_Manager_Backups");
        if (!Directory.Exists(dir)) return Array.Empty<string>();

        var prefix = Path.GetFileName(saveFolder) + "_";
        return Directory.EnumerateFiles(dir, prefix + "*.zip")
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .ToArray();
    }

    public int Validate(string zipPath, string expectedRoot)
    {
        using var zip = ZipFile.OpenRead(zipPath);
        if (zip.Entries.Count == 0)
            throw new InvalidDataException("Backup verification failed: archive is empty.");

        var root = expectedRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + "/";
        foreach (var entry in zip.Entries)
        {
            var normalized = entry.FullName.Replace('\\', '/');
            if (string.IsNullOrWhiteSpace(normalized))
                throw new InvalidDataException("Backup contains an empty path.");
            if (normalized.StartsWith("/", StringComparison.Ordinal)
                || normalized.Contains("../", StringComparison.Ordinal)
                || normalized.Contains(":", StringComparison.Ordinal))
                throw new InvalidDataException("Backup contains an unsafe path.");
            if (!normalized.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"Backup root mismatch. Expected {expectedRoot}.");
        }

        return zip.Entries.Count;
    }
}
