@echo off
setlocal
where dotnet >nul 2>&1 || (echo .NET SDK 8 or newer is required.& pause & exit /b 1)
dotnet --version
dotnet restore "PS3 Save Manager.sln" || exit /b 1
dotnet build "PS3 Save Manager.sln" -c Release || exit /b 1
dotnet publish PS3SaveManager\PS3SaveManager.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish\win-x64 || exit /b 1
echo.
echo Build complete: publish\win-x64
pause
