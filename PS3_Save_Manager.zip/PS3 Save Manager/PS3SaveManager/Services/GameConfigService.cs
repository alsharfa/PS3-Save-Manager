using System.Text.RegularExpressions;

namespace PS3SaveManager.Services;

public sealed record SecureFileRule(string FileName, string SecureFileId);

public sealed class GameConfigService
{
    private readonly string _path;
    private readonly Lazy<Dictionary<string, List<SecureFileRule>>> _rules;

    public GameConfigService(string path)
    {
        _path = path;
        _rules = new Lazy<Dictionary<string, List<SecureFileRule>>>(LoadRules, isThreadSafe: true);
    }

    public SecureFileRule? Lookup(string titleId) => LookupAll(titleId).FirstOrDefault();

    public IReadOnlyList<SecureFileRule> LookupAll(string titleId)
    {
        if (string.IsNullOrWhiteSpace(titleId)) return Array.Empty<SecureFileRule>();
        return _rules.Value.TryGetValue(titleId.Trim().ToUpperInvariant(), out var list)
            ? list
            : Array.Empty<SecureFileRule>();
    }

    private Dictionary<string, List<SecureFileRule>> LoadRules()
    {
        var result = new Dictionary<string, List<SecureFileRule>>(StringComparer.OrdinalIgnoreCase);
        if (!File.Exists(_path)) return result;

        var current = Array.Empty<string>();
        foreach (var raw in File.ReadLines(_path))
        {
            var text = raw.Trim();
            if (text.Length == 0 || text.StartsWith(';') || text.StartsWith('#')) continue;

            if (text.StartsWith("[", StringComparison.Ordinal) && text.EndsWith("]", StringComparison.Ordinal))
            {
                var group = text[1..^1];
                current = group.Split('/', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Select(x => x.ToUpperInvariant())
                    .ToArray();
                continue;
            }

            if (current.Length == 0
                || !text.StartsWith("secure_file_id:", StringComparison.OrdinalIgnoreCase)
                || !text.Contains('='))
                continue;

            var parts = text.Split('=', 2);
            var left = parts[0].Split(':', 2);
            if (left.Length != 2) continue;

            var fileName = left[1].Trim();
            var hex = Regex.Replace(parts[1], "[^0-9A-Fa-f]", "").ToUpperInvariant();
            if (fileName.Length == 0 || hex.Length != 32) continue;

            foreach (var id in current)
            {
                if (!result.TryGetValue(id, out var list))
                {
                    list = new List<SecureFileRule>();
                    result[id] = list;
                }
                if (!list.Any(x => x.FileName.Equals(fileName, StringComparison.OrdinalIgnoreCase)
                                   && x.SecureFileId.Equals(hex, StringComparison.OrdinalIgnoreCase)))
                    list.Add(new SecureFileRule(fileName, hex));
            }
        }
        return result;
    }
}
