using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;
namespace PS3SaveManager.Models;
public sealed class SaveEntry : INotifyPropertyChanged
{
    public required string FolderPath { get; init; }
    public required string Title { get; init; }
    public required string Description { get; init; }
    public required string TitleId { get; init; }
    public string Region { get; init; } = "Unknown / Not specified";
    public string CopyProtected { get; init; } = "Unknown";
    public bool HasPfd { get; init; }
    public bool HasGameKey { get; init; }
    public string SecondLayer { get; init; } = "Unknown";
    public IReadOnlyList<string> PayloadFiles { get; init; } = Array.Empty<string>();
    public ImageSource? Icon { get; init; }
    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name=null)=>PropertyChanged?.Invoke(this,new(name));
}
