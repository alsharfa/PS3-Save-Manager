@echo off
setlocal
where dotnet >nul 2>&1 || (echo .NET SDK 8 or newer is required.& pause & exit /b 1)
dotnet publish PS3SaveManager\PS3SaveManager.csproj -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -o publish\framework-dependent
pause
