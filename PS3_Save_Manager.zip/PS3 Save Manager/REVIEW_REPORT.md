# PS3 Save Manager — Review Report

## Fixed during full review

- Product/window/package name cleaned to **PS3 Save Manager**; stale `v1.0.1 - WPF` branding and the old version badge were removed.
- Preserved the requested `console_id=00000000000000000000000000000000` in `Config/global.conf`.
- Kept the safe `ICON0.PNG` loader that prevents unsupported pixel formats from crashing the save list during scrolling.
- Right-click now selects the save row under the pointer before an action runs, preventing operations on the previously selected save.
- Added an operation gate so decrypt/encrypt/verify/resign/copy-protection/undo/paste/delete cannot be double-triggered concurrently.
- Added preflight checks for Title ID, `PARAM.PFD`, `games.conf` secure-file-ID availability, and payload presence before PS3 crypto actions.
- `pfdtool.exe` plus `games.conf`/`global.conf` are now staged to a writable per-user LocalAppData runtime folder, fixing read-only install-folder failures and stale root config copies.
- Added a 10-minute pfdtool timeout with process-tree termination instead of allowing an indefinite hang.
- Added explicit `CopyToPublishDirectory` rules for pfdtool and Config files.
- `games.conf` is parsed once, cached, and supports multiple secure-file-ID rules per title.
- Save Crypto Lab now samples very large payloads rather than reading the entire file just for entropy analysis.
- Save Crypto Lab decompression has a 512 MiB output safety limit.
- Decoded Crypto Lab files are written outside the live save folder; old `.decoded` files are excluded from payload discovery.
- Payload-size display tolerates files that disappear or become inaccessible instead of crashing selection refresh.
- Remembered-profile UI now shows **Not set** when the stored PARAM.SFO path is missing or invalid.
- Settings writes are atomic (`settings.json.tmp` -> replace).
- Backup restore uses a unique safety folder and stronger archive path validation.
- Paste-over-existing now refreshes/replaces the existing UI entry instead of leaving stale metadata.
- Build scripts and solution/project paths were updated for the clean product name.

## Retained safeguards

- Backup before decrypt, encrypt/resign, resign-only, copy-protection removal, overwrite paste, delete, and undo.
- Transactional restore on failed decrypt/encrypt/resign/copy-protection operations.
- Post-encrypt and post-resign PFD verification.
- Safe delete with in-session Undo Delete.

## Validation limitation

The source/package validator passes, but this Linux execution environment does not have the .NET SDK installed, so a real WPF/Roslyn compile cannot be performed here. Run `BUILD_X64.cmd` on Windows for the authoritative compile and publish test.

## Remaining migration gaps

These files are retained for compatibility/future work but are **not currently executed by the WPF UI**:

- `Config/second_layer_rules.json`
- `Config/checksum_rules.json`

The current WPF build also does not yet include the Python project's experimental EBOOT crypto/key scanners, checksum auto-discovery/fixer, learned second-layer profile engine, AES Lab, or Title-ID/region conversion workflow. The core PS3 secure-layer decrypt/encrypt/resign/verify path is present.
